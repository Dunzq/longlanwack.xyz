<?php exit;
case 'edog': include APP_PATH.'plugin/susu_edog/hook/susu_edog.htm'; break;