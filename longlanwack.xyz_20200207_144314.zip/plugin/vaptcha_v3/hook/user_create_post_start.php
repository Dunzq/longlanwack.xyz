include_once APP_PATH.'plugin/vaptcha_v3/util/validate.php';
validate('user_create');