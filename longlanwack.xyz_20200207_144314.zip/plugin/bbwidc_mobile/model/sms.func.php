<?php

include APP_PATH.'plugin/bbwidc_mobile/model/sms_sms.func.php';


// 发送验证码接口
function sms_send_code($tomobile, $code) {
	// 根据类型调用不同的短信发送 SDK
	$kv = kv_get('mobile_setting');
	$r = FALSE;
	if($kv['send_plat'] == 'yunsms') {
		$r = sms_sms_send_code($tomobile, $code, $kv['yunsms_appid'], $kv['yunsms_appkey'], $kv['yunsms_sign']);
		if( $r['stat']=='100' )
		{
			message(0, '发送成功！');
		}
		else 
		{
			message(-1, '验证码发送失败！:'.$r['message']);
		}
	}
	return $r;
}
/*
function sms_sms_send_code($tomobile, $code, $d, $s)
{
	return false;
}
*/
// sms_send('15600900902', "您的初始密码为：123456");

/*

Array
(
    [result] => 0
    [errmsg] => OK
    [ext] => 
    [sid] => 8:xxxxxxxxxxxxxxxxxxxxxxx
    [fee] => 1
)

*/

?>